# MiniRadio (Go + Fyne + libVLC)

A tiny cross-platform internet radio mini-player built with Go, Fyne, and libVLC.

Primary target: Windows x64. Also runs on Linux/macOS if libVLC is available.

## Screenshots

![MiniRadio dark UI](images/screenshot-dark.png)

![MiniRadio Settings UI](images/settings.png)

![MiniRadio Equalizer UI](images/eq.png)

## Features
- Slim horizontal UI (~800×32) with Play/Stop, Vol−/Vol+, Mute, Settings, Equalizer buttons
- Marquee ticker showing Now Playing (best effort)
- Presets 1…0 (10 slots) via Settings; keyboard shortcuts: 1…0
- JSON config stored in user config dir

## Requirements
- Go 1.22+
- GUI: fyne.io/fyne/v2
- VLC binding: github.com/adrg/libvlc-go/v3
- Runtime: libVLC shared libs available on system

### Windows DLLs / VLC SDK
- Download the official VLC SDK (prebuilt binaries) from https://download.videolan.org/pub/videolan/vlc/ (pick the latest `vlc-<ver>-win64.zip`) or the Nightly SDK from https://nightlies.videolan.org.
- Unzip `libvlc.dll`, `libvlccore.dll`, and the `plugins/` directory into the folder that will host `miniradio.exe`.
- Alternatively install the desktop VLC player and copy the same files from `<VLC install>\`.
- When the app fails to initialize VLC, verify that the DLLs mentioned above exist next to the executable or that VLC’s `bin` directory is on `PATH`.

#### Building the DLLs yourself (optional)
VideoLAN publishes full build instructions. A minimal summary for Windows x64:
1. Install prerequisites: Git, Python 3, Ninja or GNU Make, LLVM/Clang or MSVC Build Tools, CMake, yasm, pkg-config.
2. Clone VLC and its contribs:
   ```bash
   git clone https://code.videolan.org/videolan/vlc.git
   cd vlc
   ./bootstrap
   cd contrib && mkdir win64 && cd win64
   ../bootstrap --host=x86_64-w64-mingw32
   make prebuilt        # downloads + builds third-party libs
   cd ../..
   ```
3. Configure and build VLC itself:
   ```bash
   mkdir build && cd build
   ../configure --host=x86_64-w64-mingw32 --disable-debug
   make
   make package-win-common   # produces libvlc.dll, libvlccore.dll, plugins/
   ```
The resulting DLLs and `plugins/` folder live under `build/`. Copy them next to `miniradio.exe`.

#### Minimal plugin set
MiniRadio streams HTTP(S) radio (AAC/MP3/Vorbis) only, so you can ship a reduced set of VLC plugins:

```
plugins/access/libhttp_plugin.dll
plugins/access/libhttps_plugin.dll
plugins/access/libudp_plugin.dll
plugins/demux/libplaylist_plugin.dll
plugins/demux/libasf_plugin.dll
plugins/demux/libogg_plugin.dll
plugins/codec/libfaad_plugin.dll
plugins/codec/libmpg123_plugin.dll
plugins/codec/libvorbis_plugin.dll
plugins/audio_output/libdirectsound_plugin.dll
plugins/audio_filter/libequalizer_plugin.dll
plugins/misc/liblogger_plugin.dll
plugins/stream_filter/libstream_filter_record_plugin.dll
```
(Keeping the entire `plugins/` tree also works; the list above is just the minimal footprint tested with this project.)

## How to build / run
```bash
# from repo root
go mod tidy

# run (console)
go run ./cmd/miniradio

# build Windows GUI (no console window)
go build -ldflags "-H=windowsgui" -o miniradio.exe ./cmd/miniradio

# produce a clean release folder
mkdir dist
go build -trimpath -ldflags "-s -w -H=windowsgui" -o dist/miniradio.exe ./cmd/miniradio
```

### Runtime folder layout
Put the following next to `miniradio.exe`:

```
miniradio.exe
libvlc.dll
libvlccore.dll
plugins/                # full folder or the trimmed subset listed above
config.json (created at runtime, optional)
config.example.json (optional template for new users)
```

The application loads VLC from the current directory first; no installer is required as long as these files ship together.

## Configuration
- AppID: `com.ed.miniradio`
- Config path: `<UserConfigDir>/MiniRadio/config.json`
- Quick start: copy `config.example.json` to that folder and adjust stations, volume, and EQ presets.
- Config fields cover `currentUrl`, `volume`, `muted`, `lastPreset`, ten `presets`, `windowW/H`, window position, API endpoint, and optional `customEqPresets`.

Default stream URL:
```
https://26413.live.streamtheworld.com/WMGKFMAACIHR.aac
```

## Radio Browser notes
- Uses `/json/stations/search` on `https://de1.api.radio-browser.info` by default.
- Some stations return playlists; this version uses `url_resolved` as-is.
- A simple click counter is issued on playback start (best effort).

## Troubleshooting
- If stream does not play: verify VLC DLLs presence and that the URL is a direct stream (AAC/MP3/OGG).
- If “Now Playing” is blank: the station may not send ICY metadata; ticker will show "Streaming…" or last text.
- Errors are shown via dialogs.

## License
MIT. See `LICENSE`.
